/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 3721.0, "minX": 0.0, "maxY": 26080.0, "series": [{"data": [[0.0, 3721.0], [0.1, 3728.0], [0.2, 3732.0], [0.3, 3733.0], [0.4, 3734.0], [0.5, 3736.0], [0.6, 3739.0], [0.7, 3740.0], [0.8, 3740.0], [0.9, 3742.0], [1.0, 3743.0], [1.1, 3744.0], [1.2, 3745.0], [1.3, 3746.0], [1.4, 3746.0], [1.5, 3747.0], [1.6, 3748.0], [1.7, 3749.0], [1.8, 3749.0], [1.9, 3750.0], [2.0, 3750.0], [2.1, 3751.0], [2.2, 3751.0], [2.3, 3752.0], [2.4, 3752.0], [2.5, 3753.0], [2.6, 3753.0], [2.7, 3754.0], [2.8, 3754.0], [2.9, 3754.0], [3.0, 3755.0], [3.1, 3755.0], [3.2, 3756.0], [3.3, 3756.0], [3.4, 3756.0], [3.5, 3757.0], [3.6, 3757.0], [3.7, 3757.0], [3.8, 3758.0], [3.9, 3758.0], [4.0, 3759.0], [4.1, 3759.0], [4.2, 3759.0], [4.3, 3759.0], [4.4, 3759.0], [4.5, 3760.0], [4.6, 3760.0], [4.7, 3760.0], [4.8, 3760.0], [4.9, 3760.0], [5.0, 3761.0], [5.1, 3761.0], [5.2, 3761.0], [5.3, 3761.0], [5.4, 3762.0], [5.5, 3762.0], [5.6, 3762.0], [5.7, 3762.0], [5.8, 3762.0], [5.9, 3763.0], [6.0, 3763.0], [6.1, 3763.0], [6.2, 3764.0], [6.3, 3764.0], [6.4, 3764.0], [6.5, 3764.0], [6.6, 3764.0], [6.7, 3765.0], [6.8, 3765.0], [6.9, 3765.0], [7.0, 3765.0], [7.1, 3765.0], [7.2, 3766.0], [7.3, 3766.0], [7.4, 3766.0], [7.5, 3766.0], [7.6, 3766.0], [7.7, 3767.0], [7.8, 3767.0], [7.9, 3767.0], [8.0, 3767.0], [8.1, 3768.0], [8.2, 3768.0], [8.3, 3768.0], [8.4, 3768.0], [8.5, 3768.0], [8.6, 3768.0], [8.7, 3768.0], [8.8, 3769.0], [8.9, 3769.0], [9.0, 3769.0], [9.1, 3769.0], [9.2, 3769.0], [9.3, 3769.0], [9.4, 3770.0], [9.5, 3770.0], [9.6, 3770.0], [9.7, 3770.0], [9.8, 3770.0], [9.9, 3770.0], [10.0, 3771.0], [10.1, 3771.0], [10.2, 3771.0], [10.3, 3771.0], [10.4, 3771.0], [10.5, 3771.0], [10.6, 3772.0], [10.7, 3772.0], [10.8, 3772.0], [10.9, 3772.0], [11.0, 3772.0], [11.1, 3772.0], [11.2, 3772.0], [11.3, 3773.0], [11.4, 3773.0], [11.5, 3773.0], [11.6, 3773.0], [11.7, 3773.0], [11.8, 3773.0], [11.9, 3774.0], [12.0, 3774.0], [12.1, 3774.0], [12.2, 3774.0], [12.3, 3774.0], [12.4, 3774.0], [12.5, 3775.0], [12.6, 3775.0], [12.7, 3775.0], [12.8, 3775.0], [12.9, 3775.0], [13.0, 3775.0], [13.1, 3775.0], [13.2, 3776.0], [13.3, 3776.0], [13.4, 3776.0], [13.5, 3776.0], [13.6, 3776.0], [13.7, 3776.0], [13.8, 3776.0], [13.9, 3776.0], [14.0, 3777.0], [14.1, 3777.0], [14.2, 3777.0], [14.3, 3777.0], [14.4, 3777.0], [14.5, 3777.0], [14.6, 3777.0], [14.7, 3777.0], [14.8, 3778.0], [14.9, 3778.0], [15.0, 3778.0], [15.1, 3778.0], [15.2, 3778.0], [15.3, 3778.0], [15.4, 3778.0], [15.5, 3779.0], [15.6, 3779.0], [15.7, 3779.0], [15.8, 3779.0], [15.9, 3779.0], [16.0, 3780.0], [16.1, 3780.0], [16.2, 3780.0], [16.3, 3780.0], [16.4, 3780.0], [16.5, 3780.0], [16.6, 3780.0], [16.7, 3780.0], [16.8, 3780.0], [16.9, 3781.0], [17.0, 3781.0], [17.1, 3781.0], [17.2, 3781.0], [17.3, 3781.0], [17.4, 3781.0], [17.5, 3781.0], [17.6, 3782.0], [17.7, 3782.0], [17.8, 3782.0], [17.9, 3782.0], [18.0, 3782.0], [18.1, 3782.0], [18.2, 3783.0], [18.3, 3783.0], [18.4, 3783.0], [18.5, 3783.0], [18.6, 3783.0], [18.7, 3783.0], [18.8, 3783.0], [18.9, 3783.0], [19.0, 3784.0], [19.1, 3784.0], [19.2, 3784.0], [19.3, 3784.0], [19.4, 3784.0], [19.5, 3784.0], [19.6, 3784.0], [19.7, 3784.0], [19.8, 3784.0], [19.9, 3785.0], [20.0, 3785.0], [20.1, 3785.0], [20.2, 3785.0], [20.3, 3785.0], [20.4, 3785.0], [20.5, 3785.0], [20.6, 3785.0], [20.7, 3786.0], [20.8, 3786.0], [20.9, 3786.0], [21.0, 3786.0], [21.1, 3786.0], [21.2, 3786.0], [21.3, 3786.0], [21.4, 3786.0], [21.5, 3787.0], [21.6, 3787.0], [21.7, 3787.0], [21.8, 3787.0], [21.9, 3787.0], [22.0, 3787.0], [22.1, 3787.0], [22.2, 3787.0], [22.3, 3788.0], [22.4, 3788.0], [22.5, 3788.0], [22.6, 3788.0], [22.7, 3788.0], [22.8, 3788.0], [22.9, 3788.0], [23.0, 3788.0], [23.1, 3789.0], [23.2, 3789.0], [23.3, 3789.0], [23.4, 3789.0], [23.5, 3789.0], [23.6, 3789.0], [23.7, 3789.0], [23.8, 3790.0], [23.9, 3790.0], [24.0, 3790.0], [24.1, 3790.0], [24.2, 3790.0], [24.3, 3790.0], [24.4, 3790.0], [24.5, 3790.0], [24.6, 3790.0], [24.7, 3790.0], [24.8, 3791.0], [24.9, 3791.0], [25.0, 3791.0], [25.1, 3791.0], [25.2, 3791.0], [25.3, 3791.0], [25.4, 3791.0], [25.5, 3791.0], [25.6, 3791.0], [25.7, 3791.0], [25.8, 3792.0], [25.9, 3792.0], [26.0, 3792.0], [26.1, 3792.0], [26.2, 3792.0], [26.3, 3792.0], [26.4, 3792.0], [26.5, 3792.0], [26.6, 3792.0], [26.7, 3792.0], [26.8, 3792.0], [26.9, 3793.0], [27.0, 3793.0], [27.1, 3793.0], [27.2, 3793.0], [27.3, 3793.0], [27.4, 3793.0], [27.5, 3793.0], [27.6, 3793.0], [27.7, 3794.0], [27.8, 3794.0], [27.9, 3794.0], [28.0, 3794.0], [28.1, 3794.0], [28.2, 3794.0], [28.3, 3794.0], [28.4, 3794.0], [28.5, 3794.0], [28.6, 3795.0], [28.7, 3795.0], [28.8, 3795.0], [28.9, 3795.0], [29.0, 3795.0], [29.1, 3795.0], [29.2, 3795.0], [29.3, 3796.0], [29.4, 3796.0], [29.5, 3796.0], [29.6, 3796.0], [29.7, 3796.0], [29.8, 3796.0], [29.9, 3796.0], [30.0, 3796.0], [30.1, 3796.0], [30.2, 3796.0], [30.3, 3796.0], [30.4, 3797.0], [30.5, 3797.0], [30.6, 3797.0], [30.7, 3797.0], [30.8, 3797.0], [30.9, 3797.0], [31.0, 3797.0], [31.1, 3797.0], [31.2, 3798.0], [31.3, 3798.0], [31.4, 3798.0], [31.5, 3798.0], [31.6, 3798.0], [31.7, 3798.0], [31.8, 3798.0], [31.9, 3798.0], [32.0, 3799.0], [32.1, 3799.0], [32.2, 3799.0], [32.3, 3799.0], [32.4, 3799.0], [32.5, 3799.0], [32.6, 3800.0], [32.7, 3800.0], [32.8, 3800.0], [32.9, 3800.0], [33.0, 3800.0], [33.1, 3800.0], [33.2, 3800.0], [33.3, 3800.0], [33.4, 3800.0], [33.5, 3801.0], [33.6, 3801.0], [33.7, 3801.0], [33.8, 3801.0], [33.9, 3801.0], [34.0, 3801.0], [34.1, 3801.0], [34.2, 3801.0], [34.3, 3801.0], [34.4, 3801.0], [34.5, 3802.0], [34.6, 3802.0], [34.7, 3802.0], [34.8, 3802.0], [34.9, 3802.0], [35.0, 3802.0], [35.1, 3802.0], [35.2, 3802.0], [35.3, 3803.0], [35.4, 3803.0], [35.5, 3803.0], [35.6, 3803.0], [35.7, 3803.0], [35.8, 3803.0], [35.9, 3803.0], [36.0, 3803.0], [36.1, 3804.0], [36.2, 3804.0], [36.3, 3804.0], [36.4, 3804.0], [36.5, 3804.0], [36.6, 3804.0], [36.7, 3804.0], [36.8, 3804.0], [36.9, 3805.0], [37.0, 3805.0], [37.1, 3805.0], [37.2, 3805.0], [37.3, 3805.0], [37.4, 3805.0], [37.5, 3805.0], [37.6, 3805.0], [37.7, 3806.0], [37.8, 3806.0], [37.9, 3806.0], [38.0, 3806.0], [38.1, 3806.0], [38.2, 3806.0], [38.3, 3806.0], [38.4, 3806.0], [38.5, 3806.0], [38.6, 3807.0], [38.7, 3807.0], [38.8, 3807.0], [38.9, 3807.0], [39.0, 3807.0], [39.1, 3807.0], [39.2, 3807.0], [39.3, 3807.0], [39.4, 3807.0], [39.5, 3807.0], [39.6, 3808.0], [39.7, 3808.0], [39.8, 3808.0], [39.9, 3808.0], [40.0, 3808.0], [40.1, 3808.0], [40.2, 3808.0], [40.3, 3809.0], [40.4, 3809.0], [40.5, 3809.0], [40.6, 3809.0], [40.7, 3809.0], [40.8, 3809.0], [40.9, 3809.0], [41.0, 3809.0], [41.1, 3809.0], [41.2, 3809.0], [41.3, 3810.0], [41.4, 3810.0], [41.5, 3810.0], [41.6, 3810.0], [41.7, 3810.0], [41.8, 3810.0], [41.9, 3810.0], [42.0, 3810.0], [42.1, 3811.0], [42.2, 3811.0], [42.3, 3811.0], [42.4, 3811.0], [42.5, 3811.0], [42.6, 3811.0], [42.7, 3811.0], [42.8, 3812.0], [42.9, 3812.0], [43.0, 3812.0], [43.1, 3812.0], [43.2, 3812.0], [43.3, 3812.0], [43.4, 3812.0], [43.5, 3812.0], [43.6, 3813.0], [43.7, 3813.0], [43.8, 3813.0], [43.9, 3813.0], [44.0, 3813.0], [44.1, 3813.0], [44.2, 3813.0], [44.3, 3813.0], [44.4, 3813.0], [44.5, 3814.0], [44.6, 3814.0], [44.7, 3814.0], [44.8, 3814.0], [44.9, 3814.0], [45.0, 3815.0], [45.1, 3815.0], [45.2, 3815.0], [45.3, 3815.0], [45.4, 3815.0], [45.5, 3815.0], [45.6, 3816.0], [45.7, 3816.0], [45.8, 3816.0], [45.9, 3816.0], [46.0, 3816.0], [46.1, 3816.0], [46.2, 3816.0], [46.3, 3817.0], [46.4, 3817.0], [46.5, 3817.0], [46.6, 3817.0], [46.7, 3817.0], [46.8, 3817.0], [46.9, 3818.0], [47.0, 3818.0], [47.1, 3818.0], [47.2, 3818.0], [47.3, 3818.0], [47.4, 3818.0], [47.5, 3819.0], [47.6, 3819.0], [47.7, 3819.0], [47.8, 3819.0], [47.9, 3819.0], [48.0, 3820.0], [48.1, 3820.0], [48.2, 3820.0], [48.3, 3820.0], [48.4, 3820.0], [48.5, 3820.0], [48.6, 3820.0], [48.7, 3821.0], [48.8, 3821.0], [48.9, 3821.0], [49.0, 3821.0], [49.1, 3822.0], [49.2, 3822.0], [49.3, 3822.0], [49.4, 3822.0], [49.5, 3822.0], [49.6, 3822.0], [49.7, 3823.0], [49.8, 3823.0], [49.9, 3823.0], [50.0, 3823.0], [50.1, 3823.0], [50.2, 3824.0], [50.3, 3824.0], [50.4, 3824.0], [50.5, 3824.0], [50.6, 3824.0], [50.7, 3825.0], [50.8, 3825.0], [50.9, 3825.0], [51.0, 3825.0], [51.1, 3825.0], [51.2, 3826.0], [51.3, 3826.0], [51.4, 3826.0], [51.5, 3826.0], [51.6, 3826.0], [51.7, 3826.0], [51.8, 3826.0], [51.9, 3827.0], [52.0, 3827.0], [52.1, 3827.0], [52.2, 3827.0], [52.3, 3827.0], [52.4, 3828.0], [52.5, 3828.0], [52.6, 3828.0], [52.7, 3828.0], [52.8, 3829.0], [52.9, 3829.0], [53.0, 3829.0], [53.1, 3829.0], [53.2, 3829.0], [53.3, 3829.0], [53.4, 3830.0], [53.5, 3830.0], [53.6, 3830.0], [53.7, 3830.0], [53.8, 3830.0], [53.9, 3831.0], [54.0, 3831.0], [54.1, 3831.0], [54.2, 3831.0], [54.3, 3831.0], [54.4, 3832.0], [54.5, 3832.0], [54.6, 3832.0], [54.7, 3832.0], [54.8, 3833.0], [54.9, 3833.0], [55.0, 3833.0], [55.1, 3833.0], [55.2, 3834.0], [55.3, 3834.0], [55.4, 3834.0], [55.5, 3835.0], [55.6, 3835.0], [55.7, 3835.0], [55.8, 3836.0], [55.9, 3836.0], [56.0, 3836.0], [56.1, 3836.0], [56.2, 3836.0], [56.3, 3837.0], [56.4, 3837.0], [56.5, 3837.0], [56.6, 3837.0], [56.7, 3838.0], [56.8, 3838.0], [56.9, 3838.0], [57.0, 3838.0], [57.1, 3839.0], [57.2, 3839.0], [57.3, 3839.0], [57.4, 3839.0], [57.5, 3840.0], [57.6, 3840.0], [57.7, 3841.0], [57.8, 3841.0], [57.9, 3841.0], [58.0, 3841.0], [58.1, 3842.0], [58.2, 3842.0], [58.3, 3843.0], [58.4, 3843.0], [58.5, 3844.0], [58.6, 3844.0], [58.7, 3845.0], [58.8, 3845.0], [58.9, 3846.0], [59.0, 3846.0], [59.1, 3847.0], [59.2, 3847.0], [59.3, 3847.0], [59.4, 3848.0], [59.5, 3848.0], [59.6, 3849.0], [59.7, 3849.0], [59.8, 3849.0], [59.9, 3850.0], [60.0, 3850.0], [60.1, 3851.0], [60.2, 3851.0], [60.3, 3852.0], [60.4, 3852.0], [60.5, 3854.0], [60.6, 3854.0], [60.7, 3855.0], [60.8, 3856.0], [60.9, 3857.0], [61.0, 3857.0], [61.1, 3858.0], [61.2, 3859.0], [61.3, 3859.0], [61.4, 3860.0], [61.5, 3861.0], [61.6, 3862.0], [61.7, 3862.0], [61.8, 3863.0], [61.9, 3864.0], [62.0, 3865.0], [62.1, 3866.0], [62.2, 3867.0], [62.3, 3868.0], [62.4, 3869.0], [62.5, 3870.0], [62.6, 3871.0], [62.7, 3872.0], [62.8, 3873.0], [62.9, 3875.0], [63.0, 3876.0], [63.1, 3878.0], [63.2, 3879.0], [63.3, 3880.0], [63.4, 3881.0], [63.5, 3883.0], [63.6, 3886.0], [63.7, 3886.0], [63.8, 3887.0], [63.9, 3889.0], [64.0, 3891.0], [64.1, 3893.0], [64.2, 3894.0], [64.3, 3895.0], [64.4, 3896.0], [64.5, 3900.0], [64.6, 3902.0], [64.7, 3905.0], [64.8, 3909.0], [64.9, 3911.0], [65.0, 3914.0], [65.1, 3918.0], [65.2, 3923.0], [65.3, 3926.0], [65.4, 3932.0], [65.5, 3936.0], [65.6, 3940.0], [65.7, 3945.0], [65.8, 3947.0], [65.9, 3952.0], [66.0, 3955.0], [66.1, 3959.0], [66.2, 3965.0], [66.3, 3969.0], [66.4, 3971.0], [66.5, 3979.0], [66.6, 3983.0], [66.7, 3990.0], [66.8, 3997.0], [66.9, 4002.0], [67.0, 4010.0], [67.1, 4013.0], [67.2, 4028.0], [67.3, 4032.0], [67.4, 4040.0], [67.5, 4051.0], [67.6, 4056.0], [67.7, 4058.0], [67.8, 4060.0], [67.9, 4067.0], [68.0, 4071.0], [68.1, 4075.0], [68.2, 4081.0], [68.3, 4091.0], [68.4, 4100.0], [68.5, 4106.0], [68.6, 4114.0], [68.7, 4127.0], [68.8, 4133.0], [68.9, 4147.0], [69.0, 4150.0], [69.1, 4163.0], [69.2, 4172.0], [69.3, 4181.0], [69.4, 4194.0], [69.5, 4205.0], [69.6, 4218.0], [69.7, 4239.0], [69.8, 4252.0], [69.9, 4277.0], [70.0, 4299.0], [70.1, 4311.0], [70.2, 4350.0], [70.3, 4417.0], [70.4, 4509.0], [70.5, 4578.0], [70.6, 4779.0], [70.7, 4800.0], [70.8, 4807.0], [70.9, 4814.0], [71.0, 4820.0], [71.1, 4861.0], [71.2, 5123.0], [71.3, 6805.0], [71.4, 6934.0], [71.5, 6993.0], [71.6, 7036.0], [71.7, 7083.0], [71.8, 10806.0], [71.9, 10826.0], [72.0, 18832.0], [72.1, 18920.0], [72.2, 24615.0], [72.3, 24623.0], [72.4, 24625.0], [72.5, 24628.0], [72.6, 24630.0], [72.7, 24632.0], [72.8, 24633.0], [72.9, 24635.0], [73.0, 24637.0], [73.1, 24637.0], [73.2, 24639.0], [73.3, 24640.0], [73.4, 24641.0], [73.5, 24642.0], [73.6, 24644.0], [73.7, 24644.0], [73.8, 24645.0], [73.9, 24647.0], [74.0, 24647.0], [74.1, 24649.0], [74.2, 24649.0], [74.3, 24649.0], [74.4, 24650.0], [74.5, 24650.0], [74.6, 24650.0], [74.7, 24651.0], [74.8, 24651.0], [74.9, 24652.0], [75.0, 24652.0], [75.1, 24653.0], [75.2, 24654.0], [75.3, 24654.0], [75.4, 24655.0], [75.5, 24655.0], [75.6, 24655.0], [75.7, 24656.0], [75.8, 24656.0], [75.9, 24657.0], [76.0, 24657.0], [76.1, 24658.0], [76.2, 24658.0], [76.3, 24658.0], [76.4, 24659.0], [76.5, 24659.0], [76.6, 24659.0], [76.7, 24660.0], [76.8, 24660.0], [76.9, 24661.0], [77.0, 24661.0], [77.1, 24661.0], [77.2, 24662.0], [77.3, 24662.0], [77.4, 24662.0], [77.5, 24663.0], [77.6, 24663.0], [77.7, 24663.0], [77.8, 24664.0], [77.9, 24664.0], [78.0, 24664.0], [78.1, 24665.0], [78.2, 24665.0], [78.3, 24665.0], [78.4, 24666.0], [78.5, 24666.0], [78.6, 24666.0], [78.7, 24667.0], [78.8, 24667.0], [78.9, 24667.0], [79.0, 24668.0], [79.1, 24668.0], [79.2, 24669.0], [79.3, 24669.0], [79.4, 24670.0], [79.5, 24670.0], [79.6, 24670.0], [79.7, 24671.0], [79.8, 24671.0], [79.9, 24671.0], [80.0, 24672.0], [80.1, 24672.0], [80.2, 24673.0], [80.3, 24673.0], [80.4, 24673.0], [80.5, 24673.0], [80.6, 24674.0], [80.7, 24674.0], [80.8, 24674.0], [80.9, 24674.0], [81.0, 24675.0], [81.1, 24675.0], [81.2, 24675.0], [81.3, 24675.0], [81.4, 24675.0], [81.5, 24676.0], [81.6, 24676.0], [81.7, 24677.0], [81.8, 24677.0], [81.9, 24677.0], [82.0, 24678.0], [82.1, 24678.0], [82.2, 24678.0], [82.3, 24678.0], [82.4, 24679.0], [82.5, 24679.0], [82.6, 24680.0], [82.7, 24680.0], [82.8, 24680.0], [82.9, 24681.0], [83.0, 24681.0], [83.1, 24682.0], [83.2, 24682.0], [83.3, 24682.0], [83.4, 24682.0], [83.5, 24683.0], [83.6, 24683.0], [83.7, 24683.0], [83.8, 24683.0], [83.9, 24683.0], [84.0, 24684.0], [84.1, 24684.0], [84.2, 24684.0], [84.3, 24685.0], [84.4, 24685.0], [84.5, 24685.0], [84.6, 24686.0], [84.7, 24686.0], [84.8, 24686.0], [84.9, 24687.0], [85.0, 24687.0], [85.1, 24688.0], [85.2, 24688.0], [85.3, 24688.0], [85.4, 24688.0], [85.5, 24689.0], [85.6, 24689.0], [85.7, 24690.0], [85.8, 24690.0], [85.9, 24690.0], [86.0, 24690.0], [86.1, 24691.0], [86.2, 24691.0], [86.3, 24691.0], [86.4, 24691.0], [86.5, 24691.0], [86.6, 24692.0], [86.7, 24692.0], [86.8, 24692.0], [86.9, 24692.0], [87.0, 24693.0], [87.1, 24693.0], [87.2, 24693.0], [87.3, 24694.0], [87.4, 24694.0], [87.5, 24695.0], [87.6, 24695.0], [87.7, 24695.0], [87.8, 24695.0], [87.9, 24696.0], [88.0, 24696.0], [88.1, 24696.0], [88.2, 24697.0], [88.3, 24697.0], [88.4, 24697.0], [88.5, 24697.0], [88.6, 24697.0], [88.7, 24698.0], [88.8, 24698.0], [88.9, 24698.0], [89.0, 24699.0], [89.1, 24699.0], [89.2, 24699.0], [89.3, 24700.0], [89.4, 24700.0], [89.5, 24700.0], [89.6, 24700.0], [89.7, 24701.0], [89.8, 24701.0], [89.9, 24701.0], [90.0, 24702.0], [90.1, 24702.0], [90.2, 24702.0], [90.3, 24702.0], [90.4, 24703.0], [90.5, 24703.0], [90.6, 24704.0], [90.7, 24704.0], [90.8, 24704.0], [90.9, 24705.0], [91.0, 24705.0], [91.1, 24706.0], [91.2, 24706.0], [91.3, 24707.0], [91.4, 24707.0], [91.5, 24708.0], [91.6, 24708.0], [91.7, 24708.0], [91.8, 24709.0], [91.9, 24710.0], [92.0, 24710.0], [92.1, 24710.0], [92.2, 24711.0], [92.3, 24712.0], [92.4, 24712.0], [92.5, 24713.0], [92.6, 24714.0], [92.7, 24714.0], [92.8, 24714.0], [92.9, 24714.0], [93.0, 24715.0], [93.1, 24716.0], [93.2, 24716.0], [93.3, 24717.0], [93.4, 24717.0], [93.5, 24718.0], [93.6, 24718.0], [93.7, 24719.0], [93.8, 24720.0], [93.9, 24720.0], [94.0, 24720.0], [94.1, 24721.0], [94.2, 24722.0], [94.3, 24722.0], [94.4, 24723.0], [94.5, 24723.0], [94.6, 24724.0], [94.7, 24725.0], [94.8, 24725.0], [94.9, 24726.0], [95.0, 24727.0], [95.1, 24727.0], [95.2, 24728.0], [95.3, 24728.0], [95.4, 24729.0], [95.5, 24730.0], [95.6, 24731.0], [95.7, 24732.0], [95.8, 24733.0], [95.9, 24733.0], [96.0, 24734.0], [96.1, 24735.0], [96.2, 24736.0], [96.3, 24737.0], [96.4, 24739.0], [96.5, 24740.0], [96.6, 24741.0], [96.7, 24743.0], [96.8, 24744.0], [96.9, 24745.0], [97.0, 24748.0], [97.1, 24750.0], [97.2, 24753.0], [97.3, 24756.0], [97.4, 24762.0], [97.5, 24764.0], [97.6, 24766.0], [97.7, 24767.0], [97.8, 24771.0], [97.9, 24773.0], [98.0, 24777.0], [98.1, 24779.0], [98.2, 24786.0], [98.3, 24794.0], [98.4, 24796.0], [98.5, 24811.0], [98.6, 24834.0], [98.7, 24842.0], [98.8, 24853.0], [98.9, 24874.0], [99.0, 24890.0], [99.1, 24946.0], [99.2, 24962.0], [99.3, 24983.0], [99.4, 25019.0], [99.5, 25042.0], [99.6, 25075.0], [99.7, 25111.0], [99.8, 25147.0], [99.9, 25221.0]], "isOverall": false, "label": "DELAYED RESPONSE", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 3700.0, "maxY": 1445.0, "series": [{"data": [[10700.0, 2.0], [10800.0, 8.0], [18800.0, 6.0], [19000.0, 1.0], [18900.0, 1.0], [24600.0, 760.0], [24700.0, 408.0], [24800.0, 26.0], [24900.0, 14.0], [25000.0, 16.0], [25100.0, 9.0], [25200.0, 3.0], [26000.0, 1.0], [25600.0, 1.0], [3700.0, 1445.0], [3800.0, 1419.0], [3900.0, 105.0], [4000.0, 69.0], [4100.0, 47.0], [4300.0, 11.0], [4200.0, 25.0], [4500.0, 6.0], [4400.0, 6.0], [4600.0, 2.0], [4800.0, 21.0], [4700.0, 5.0], [5100.0, 2.0], [4900.0, 1.0], [5200.0, 1.0], [5800.0, 1.0], [6900.0, 9.0], [6800.0, 1.0], [6700.0, 1.0], [7000.0, 8.0], [7200.0, 1.0]], "isOverall": false, "label": "DELAYED RESPONSE", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 26000.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 1473.0, "minX": 2.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 2969.0, "series": [{"data": [], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[2.0, 2969.0]], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [[3.0, 1473.0]], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 3.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 101.92241379310347, "minX": 1.63225242E12, "maxY": 211.0, "series": [{"data": [[1.63225242E12, 188.38992042440313], [1.6322526E12, 208.80551523947733], [1.63225266E12, 101.92241379310347], [1.63225248E12, 211.0], [1.63225254E12, 211.0]], "isOverall": false, "label": "jp@gc - Ultimate Thread Group Scenario 3", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.63225266E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 21600000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 3748.0, "minX": 1.0, "maxY": 25672.0, "series": [{"data": [[2.0, 24785.0], [3.0, 25037.0], [4.0, 25044.0], [5.0, 24692.0], [6.0, 11137.333333333332], [7.0, 24710.0], [8.0, 10896.333333333332], [9.0, 14294.0], [10.0, 24713.0], [11.0, 24683.0], [12.0, 24652.0], [13.0, 24690.0], [14.0, 25672.0], [15.0, 24638.0], [16.0, 24712.0], [17.0, 24677.0], [18.0, 24729.0], [19.0, 24719.0], [20.0, 24710.0], [21.0, 24668.0], [22.0, 14253.5], [23.0, 24667.0], [24.0, 24645.0], [25.0, 24947.0], [26.0, 24672.0], [27.0, 24647.0], [28.0, 24721.0], [29.0, 25043.0], [30.0, 24687.0], [31.0, 24714.0], [33.0, 24735.0], [32.0, 24675.0], [35.0, 24725.0], [34.0, 24730.0], [37.0, 24699.0], [36.0, 24705.0], [39.0, 24668.0], [38.0, 24715.0], [41.0, 24669.0], [40.0, 24691.0], [43.0, 24637.0], [42.0, 24677.0], [45.0, 24702.0], [44.0, 24655.0], [46.0, 14271.5], [47.0, 24691.0], [49.0, 14249.5], [48.0, 24684.0], [51.0, 24661.0], [50.0, 24691.0], [53.0, 24669.0], [52.0, 24714.0], [55.0, 24727.0], [54.0, 24664.0], [57.0, 24678.0], [56.0, 24664.0], [59.0, 24675.0], [58.0, 24696.0], [61.0, 24728.0], [60.0, 24708.0], [63.0, 24652.0], [62.0, 24700.0], [64.0, 14254.5], [67.0, 24670.0], [66.0, 24661.0], [65.0, 24687.0], [71.0, 24698.0], [70.0, 24845.0], [69.0, 24706.0], [68.0, 24714.0], [75.0, 24725.0], [74.0, 24743.0], [73.0, 24716.0], [72.0, 24673.0], [79.0, 3807.0], [78.0, 24688.0], [77.0, 24676.0], [76.0, 3800.0], [83.0, 3748.0], [82.0, 24691.0], [81.0, 24721.0], [80.0, 24692.0], [85.0, 3810.0], [86.0, 14248.5], [87.0, 3805.0], [84.0, 24712.0], [89.0, 10768.333333333332], [91.0, 14239.0], [90.0, 24674.0], [88.0, 24694.0], [93.0, 14244.5], [95.0, 10754.0], [94.0, 24705.0], [92.0, 24657.0], [97.0, 14230.0], [98.0, 17702.333333333332], [99.0, 10766.0], [96.0, 3763.0], [101.0, 3817.0], [103.0, 9027.75], [102.0, 24650.0], [100.0, 24719.0], [104.0, 3761.5], [106.0, 3788.5], [107.0, 24677.0], [105.0, 24675.0], [108.0, 3789.3333333333335], [110.0, 9019.25], [109.0, 24668.0], [112.0, 9302.25], [113.0, 3796.3333333333335], [115.0, 3777.0], [114.0, 14236.0], [116.0, 10917.666666666666], [117.0, 3801.0], [118.0, 3813.75], [119.0, 24740.0], [120.0, 3857.0], [122.0, 10803.0], [123.0, 3845.0], [121.0, 24722.0], [124.0, 14276.5], [125.0, 14292.5], [126.0, 10778.0], [127.0, 24730.0], [130.0, 14261.0], [131.0, 10771.0], [132.0, 14243.0], [135.0, 3796.5], [134.0, 3801.0], [133.0, 24665.0], [129.0, 3820.5], [128.0, 3802.0], [136.0, 14252.5], [137.0, 4304.5], [140.0, 12150.8], [142.0, 9019.0], [143.0, 10739.0], [141.0, 24682.0], [139.0, 14243.5], [138.0, 3792.0], [144.0, 8133.4], [145.0, 8024.6], [147.0, 14243.0], [149.0, 17763.0], [150.0, 3880.6666666666665], [151.0, 10796.333333333332], [148.0, 3795.5], [146.0, 3777.0], [152.0, 10773.0], [153.0, 15865.5], [154.0, 3815.0], [157.0, 9053.5], [158.0, 14222.0], [159.0, 3771.0], [156.0, 3766.0], [155.0, 8591.8], [160.0, 3884.0], [161.0, 12130.4], [162.0, 10787.333333333332], [163.0, 5889.8], [164.0, 14242.25], [166.0, 12137.0], [167.0, 10776.666666666668], [165.0, 3794.0], [168.0, 12166.6], [169.0, 8008.0], [170.0, 8008.6], [171.0, 4040.0], [173.0, 9019.25], [175.0, 3843.5], [174.0, 24695.0], [172.0, 3832.0], [176.0, 3899.8333333333335], [178.0, 9036.5], [179.0, 8998.25], [180.0, 8447.666666666666], [181.0, 12763.857142857143], [182.0, 3806.8571428571427], [183.0, 3791.5], [177.0, 14240.5], [184.0, 3781.5], [185.0, 3787.0], [186.0, 7966.300000000001], [188.0, 10746.0], [189.0, 3779.0], [190.0, 10761.0], [191.0, 10750.0], [187.0, 14320.166666666666], [193.0, 10765.333333333332], [194.0, 3805.0], [195.0, 10741.333333333332], [196.0, 10769.0], [197.0, 6246.352941176471], [198.0, 7961.099999999999], [199.0, 4048.0], [192.0, 8024.4], [200.0, 14350.749999999998], [201.0, 3812.0], [202.0, 7289.285714285715], [203.0, 8393.857142857145], [205.0, 3940.6666666666665], [207.0, 3943.3333333333335], [206.0, 14670.5], [204.0, 17066.8], [208.0, 3832.6], [209.0, 11640.625], [210.0, 8687.300000000001], [211.0, 9460.999744310864], [1.0, 24705.0]], "isOverall": false, "label": "DELAYED RESPONSE", "isController": false}, {"data": [[202.70328680774423, 9709.863574966217]], "isOverall": false, "label": "DELAYED RESPONSE-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 211.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 506.53333333333336, "minX": 1.63225242E12, "maxY": 43029.86666666667, "series": [{"data": [[1.63225242E12, 11653.15], [1.6322526E12, 42594.13333333333], [1.63225266E12, 7171.233333333334], [1.63225248E12, 32857.15], [1.63225254E12, 43029.86666666667]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.63225242E12, 823.1166666666667], [1.6322526E12, 3008.633333333333], [1.63225266E12, 506.53333333333336], [1.63225248E12, 2320.883333333333], [1.63225254E12, 3039.2]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.63225266E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 21600000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 3921.4297082228113, "minX": 1.63225242E12, "maxY": 17345.133620689652, "series": [{"data": [[1.63225242E12, 3921.4297082228113], [1.6322526E12, 9185.02394775035], [1.63225266E12, 17345.133620689652], [1.63225248E12, 11262.01505174036], [1.63225254E12, 9339.280890804595]], "isOverall": false, "label": "DELAYED RESPONSE", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.63225266E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 21600000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 3919.7374005305055, "minX": 1.63225242E12, "maxY": 17344.711206896558, "series": [{"data": [[1.63225242E12, 3919.7374005305055], [1.6322526E12, 9183.317126269952], [1.63225266E12, 17344.711206896558], [1.63225248E12, 11261.158043273754], [1.63225254E12, 9336.87356321838]], "isOverall": false, "label": "DELAYED RESPONSE", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.63225266E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 21600000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 417.8328912466841, "minX": 1.63225242E12, "maxY": 13866.129310344833, "series": [{"data": [[1.63225242E12, 417.8328912466841], [1.6322526E12, 5691.029027576204], [1.63225266E12, 13866.129310344833], [1.63225248E12, 7778.722483537159], [1.63225254E12, 5845.520114942525]], "isOverall": false, "label": "DELAYED RESPONSE", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.63225266E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 21600000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 3721.0, "minX": 1.63225242E12, "maxY": 3999.0, "series": [{"data": [[1.63225242E12, 3992.0], [1.6322526E12, 3996.0], [1.63225266E12, 3981.0], [1.63225248E12, 3999.0], [1.63225254E12, 3997.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.63225242E12, 3856.4], [1.6322526E12, 3854.0], [1.63225266E12, 3861.7000000000003], [1.63225248E12, 3847.3], [1.63225254E12, 3855.2]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.63225242E12, 3983.98], [1.6322526E12, 3961.04], [1.63225266E12, 3981.0], [1.63225248E12, 3923.8599999999997], [1.63225254E12, 3962.7200000000003]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.63225242E12, 3896.7], [1.6322526E12, 3884.1], [1.63225266E12, 3902.1], [1.63225248E12, 3866.3], [1.63225254E12, 3893.0]], "isOverall": false, "label": "95th percentile", "isController": false}, {"data": [[1.63225242E12, 3734.0], [1.6322526E12, 3721.0], [1.63225266E12, 3741.0], [1.63225248E12, 3723.0], [1.63225254E12, 3721.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.63225242E12, 3807.0], [1.6322526E12, 3801.0], [1.63225266E12, 3801.5], [1.63225248E12, 3801.0], [1.63225254E12, 3797.0]], "isOverall": false, "label": "Median", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.63225266E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 21600000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 3763.0, "minX": 1.0, "maxY": 24714.5, "series": [{"data": [[2.0, 3831.0], [32.0, 3805.0], [33.0, 3844.0], [35.0, 3808.5], [34.0, 3857.0], [36.0, 3794.0], [38.0, 3785.5], [40.0, 3804.0], [7.0, 3763.0], [8.0, 3783.0], [9.0, 3820.0], [10.0, 3802.0], [11.0, 3801.0], [12.0, 3820.0], [13.0, 3804.0], [14.0, 3813.0], [15.0, 3795.0], [1.0, 3839.0], [16.0, 3805.0], [17.0, 3810.5], [18.0, 3806.5], [19.0, 3801.0], [20.0, 3800.0], [21.0, 3798.0], [22.0, 3796.0], [23.0, 3796.0], [24.0, 3799.0], [25.0, 3801.0], [26.0, 3798.0], [27.0, 3802.0], [28.0, 3807.0], [29.0, 3798.0], [30.0, 3788.0], [31.0, 3786.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[32.0, 24672.0], [33.0, 24666.0], [2.0, 24706.5], [35.0, 24682.5], [34.0, 4878.0], [36.0, 4798.0], [38.0, 24687.0], [40.0, 24696.0], [3.0, 24714.5], [4.0, 24695.0], [5.0, 24696.0], [6.0, 24670.0], [7.0, 24688.0], [8.0, 24674.0], [9.0, 24692.0], [10.0, 24687.5], [11.0, 24682.0], [12.0, 4548.0], [13.0, 24701.0], [14.0, 24693.0], [15.0, 24692.0], [1.0, 24687.5], [16.0, 24680.0], [17.0, 24692.0], [18.0, 24684.0], [19.0, 24664.0], [20.0, 24690.0], [21.0, 24678.5], [22.0, 24665.0], [23.0, 24683.0], [24.0, 24683.0], [25.0, 24686.0], [26.0, 24681.5], [27.0, 24692.0], [28.0, 24680.5], [29.0, 24675.0], [30.0, 24674.0], [31.0, 24663.5]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 40.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 3762.0, "minX": 1.0, "maxY": 24714.5, "series": [{"data": [[2.0, 3831.0], [32.0, 3805.0], [33.0, 3844.0], [35.0, 3808.5], [34.0, 3857.0], [36.0, 3794.0], [38.0, 3785.5], [40.0, 3804.0], [7.0, 3762.0], [8.0, 3782.5], [9.0, 3819.0], [10.0, 3801.5], [11.0, 3801.0], [12.0, 3819.0], [13.0, 3804.0], [14.0, 3813.0], [15.0, 3795.0], [1.0, 3839.0], [16.0, 3804.0], [17.0, 3809.5], [18.0, 3806.0], [19.0, 3801.0], [20.0, 3800.0], [21.0, 3798.0], [22.0, 3795.0], [23.0, 3796.0], [24.0, 3799.0], [25.0, 3801.0], [26.0, 3797.5], [27.0, 3802.0], [28.0, 3806.5], [29.0, 3797.0], [30.0, 3788.0], [31.0, 3784.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[32.0, 24671.0], [33.0, 24666.0], [2.0, 24705.0], [35.0, 24682.5], [34.0, 4878.0], [36.0, 4798.0], [38.0, 24687.0], [40.0, 24694.5], [3.0, 24714.5], [4.0, 24695.0], [5.0, 24695.5], [6.0, 24670.0], [7.0, 24688.0], [8.0, 24674.0], [9.0, 24692.0], [10.0, 24687.5], [11.0, 24682.0], [12.0, 4548.0], [13.0, 24701.0], [14.0, 24690.0], [15.0, 24692.0], [1.0, 24687.5], [16.0, 24680.0], [17.0, 24691.0], [18.0, 24683.5], [19.0, 24664.0], [20.0, 24690.0], [21.0, 24678.0], [22.0, 24665.0], [23.0, 24683.0], [24.0, 24683.0], [25.0, 24686.0], [26.0, 24681.5], [27.0, 24692.0], [28.0, 24679.5], [29.0, 24674.0], [30.0, 24674.0], [31.0, 24663.5]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 40.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 1.05, "minX": 1.63225242E12, "maxY": 23.2, "series": [{"data": [[1.63225242E12, 9.8], [1.6322526E12, 22.266666666666666], [1.63225266E12, 1.05], [1.63225248E12, 17.716666666666665], [1.63225254E12, 23.2]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.63225266E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 21600000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 3.8666666666666667, "minX": 1.63225242E12, "maxY": 23.2, "series": [{"data": [[1.63225242E12, 6.283333333333333], [1.6322526E12, 22.966666666666665], [1.63225266E12, 3.8666666666666667], [1.63225248E12, 17.716666666666665], [1.63225254E12, 23.2]], "isOverall": false, "label": "200", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.63225266E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 21600000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 0.45, "minX": 1.63225242E12, "maxY": 15.8, "series": [{"data": [[1.63225242E12, 5.833333333333333], [1.6322526E12, 15.8], [1.63225266E12, 1.3], [1.63225248E12, 10.933333333333334], [1.63225254E12, 15.616666666666667]], "isOverall": false, "label": "DELAYED RESPONSE-success", "isController": false}, {"data": [[1.63225242E12, 0.45], [1.6322526E12, 7.166666666666667], [1.63225266E12, 2.566666666666667], [1.63225248E12, 6.783333333333333], [1.63225254E12, 7.583333333333333]], "isOverall": false, "label": "DELAYED RESPONSE-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.63225266E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 21600000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 0.45, "minX": 1.63225242E12, "maxY": 15.8, "series": [{"data": [[1.63225242E12, 5.833333333333333], [1.6322526E12, 15.8], [1.63225266E12, 1.3], [1.63225248E12, 10.933333333333334], [1.63225254E12, 15.616666666666667]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [[1.63225242E12, 0.45], [1.6322526E12, 7.166666666666667], [1.63225266E12, 2.566666666666667], [1.63225248E12, 6.783333333333333], [1.63225254E12, 7.583333333333333]], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.63225266E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 21600000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

